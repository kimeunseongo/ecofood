let data = [
    {
        id: 0,
        title2: "★★★★★",
        title: "White and Black Buger",
        imgUrl: "img/underimg1.jpg",
        content: "Born in France",
        price: 12000
    },
    {
        id: 1,
        title2: "★★★★★",
        title: "Tofu French Egg Salad",
        imgUrl: "img/underimg2.jpg",
        content: "Born in Seoul",
        price: 110000
    },
    {
        id: 2,
        title2: "★★★★★",
        title: "Balsamic Green Pasta Salad",
        imgUrl: "img/underimg3.jpg",
        content: "Born in the States",
        price: 130000
    },
    {
        id : 3,
        title2: "★★★★★",
        title : "Ricotta tomato wave salad",
        imgUrl: "img/underimg4.jpg",
        content : "only 5 inches",
        price : 150000
      },
      {
        id : 4,
        title2: "★★★★★",
        title : "Healthy vegetables ice slush",
        imgUrl: "img/underimg5.jpg",
        content : "for less than 6",
        price : 140000
      },
      {
        id : 5,
        title2: "★★★★★",
        title : "Egg Avocado Salad",
        imgUrl: "img/underimg6.jpg",
        content : "Born in France",
        price : 120000
      },
      {
        id : 6,
        title2: "★★★★★",
        title : "Egg Slot Avocado Fried Rice",
        imgUrl: "img/underimg7.jpg",
        content : "only 5 inches",
        price : 170000
      },
      {
        id : 7,
        title2: "★★★★★",
        title : "Baked Salmon with Butter",
        imgUrl: "img/underimg8.jpg",
        content : "for less than 6",
        price : 160000
      }
]

export default data;



