
import './App.css';
import React from 'react';
import {Button, Navbar, Container, Nav,Row,Col,Carousel,Form,NavDropdown} from 'react-bootstrap'
import data from './data.js';
import { useState } from 'react';
import Detail from './Detail';
import { Routes, Route, Link, useNavigate, Outlet } from 'react-router-dom'
import nike from './nike';
import axios from 'axios'
import Cart from './Cart.js'








function App() {

  let [shoes, setShoes] = useState(data);
  let navigate = useNavigate();
  let [res1, setRes1] = useState([0,1,2,3,4,5,6,7,8]);
  let [nike10, setNike10] = useState(nike);
  let [count, setCount] = useState(1);



  return (
    <div className="App">




{/* ------여기서부터 네비게이션-------- */}

    <>



    <Navbar bg="light" expand="lg" sticky="top">
      <Container fluid     >
        <Navbar.Brand href="#"> <img
          src="img/foodimg/logo.png"
          height="40"
          alt="Logo"
          loading="lazy"
        /></Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll" >
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: 'auto' }}
            navbarScroll
          >
            <Nav.Link  onClick={()=>{ navigate('/')}} style={{ 
                  cursor:'pointer',
                  fontFamily: 'Crimson Text',
                  fontWeight:'600',
                  fontSize:'18px'
                }}>Home</Nav.Link>
            <Nav.Link  onClick={()=>{ navigate('/detail/0')}} style={{ 
                  cursor:'pointer',
                  fontFamily: 'Crimson Text',
                  fontWeight:'600',
                  fontSize:'18px'

                }}>shop</Nav.Link>
            
            <Nav.Link onClick={()=>{ navigate('/Cart')}} style={{ 
                  cursor:'pointer',
                  fontFamily: 'Crimson Text',
                  fontWeight:'600',
                  fontSize:'18px'
                }}>cart</Nav.Link>

            <NavDropdown title="about" id="navbarScrollingDropdown" onClick={()=>{ navigate('/About')}} style={{ 
                  cursor:'pointer',
                  fontFamily: 'Crimson Text',
                  fontWeight:'600',
                  fontSize:'18px'
                }}>

              <NavDropdown.Item href="#action3">company</NavDropdown.Item>
              <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
              
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action5">
                Something else here
              </NavDropdown.Item>
            </NavDropdown>


          </Nav>


          <Form className="d-flex" style={{ fontFamily: 'Crimson Text'}}>
            <Form.Control
              type="search"
              placeholder="Search for Delicious Salad!"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-success">Search</Button>
          </Form>


          <Nav.Link onClick={()=>{ navigate('/Cart')}} style={{ 
                  cursor:'pointer',
                  fontSize:'23px',
                  fontFamily: 'Crimson Text',
                  float:'right',
                  color:'#888888'
                }}><i class="fa-solid fa-sliders"></i>      <i class="fa-solid fa-user" style={{marginLeft:'10px'}}></i></Nav.Link>
        </Navbar.Collapse>
      </Container>
    </Navbar>
   
    </>

{/* ------여기까지 네비게이션-------- */}

<Routes>

          {/* ------여기부터 메인페이지시작-------- */}
          <Route path="/" 
          element=
          {<div>
              <>
             
              

 {/* -----여기서부터 슬라이더------- */}

 <>
    <div >

    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="img/slider11.png"
          alt="First slide"
        />
        <Carousel.Caption>
         
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="img/slider22.png"
          alt="Second slide"
        />

        <Carousel.Caption>
         
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="img/slider33.png"
          alt="Third slide"
        />

        <Carousel.Caption>
         
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>

      
    </div>
 </>




 {/* -----여기까지 슬라이더------- */}


                  {/* 슬라이더 밑에 아이콘 4개들 */}
                    
                     <Sliderline/>

                  {/* 아이콘및에 글씨 */}

                       <Thirdline/>

                    

              <Title/> {/* 첫라인 문구 MOST POPULAR */}

              
                    {/* 여기부터 버튼들 시작 */}

                    <Button variant="outline-primary"  style={{fontFamily: 'Cormorant Garamond',fontWeight:'600',marginBottom:'10px'}}  onClick={()=>{
                    let copy3 = [...shoes].sort((a, b) =>
                      a.title > b.title ? 1 : -1,
                    );
              
                    setShoes(copy3);
                    shoes = copy3;
            
                    var res=[];
                    for(let i in shoes) {
                      res.push(shoes[i].id);
                    }
                    setRes1(res1=res);

                  }}>Sort by name</Button>{' '}

                  <Button variant="outline-secondary"  style={{fontFamily: 'Cormorant Garamond',fontWeight:'600',marginBottom:'10px'}} onClick={()=>{
                                    let copy4 = [...shoes].sort((a, b) =>
                                      a.price > b.price ? 1 : -1,
                                    );
                            
                                    setShoes(copy4);
                                    shoes = copy4;
                                    var res=[];
                                    for(let i in shoes) {
                                      res.push(shoes[i].id);
                                    }
                                    setRes1(res1=res);
                  
                                }}>the lowest net price</Button>{' '}

                                

                      <Button variant="outline-success" style={{fontFamily: 'Cormorant Garamond',fontWeight:'600',marginBottom:'10px'}} onClick={()=>{
                              let copy5 = [...shoes].sort((a, b) =>
                                b.price > a.price ? 1 : -1,
                              );
                              setShoes(copy5);
                              shoes = copy5;
                              var res=[];
                              for(let i in shoes) {
                                res.push(shoes[i].id);
                              }
                              setRes1(res1=res);
                

              }}>the highest net price</Button>{' '}






                  {/* 여기부터 버튼들 끝 */}

   {/* -----여기부터 첫 상품들 most popular-------- */}


              
        
        <div className="container" style={{marginTop:'30px'}}>

            <div className="row" >
                  {
                    shoes.map((ele, i) => {
                    return (
                      <Product shoes={shoes[i]} res1={res1} i={i} />
                    )
                    })
                  }
            </div>


        </div>


              
 {/* -----여기까지 첫 상품들 most popular-------- */}



        

                 <Title2/> {/* // ---HEALTHY DIET 두번째 라인----- */}

                  

                    {/* 여기부터 두번째 버튼 시작*/}

                    <Button variant="outline-success" style={{fontFamily: 'Cormorant Garamond',fontWeight:'600'}} count = {count} onClick={()=>{

                      if(count==1){
                        axios.get('https://kimeunseongo.github.io/react_data2/nike2.json').then((result)=>{
                            let copy10 =[...nike10, ...result.data];
                            setNike10(copy10);
                            setCount(2);

                      })}else if(count==2){
                        axios.get('https://kimeunseongo.github.io/react_data2/nike3.json').then((result)=>{

                          let copy11 =[...nike10, ...result.data];
                          setNike10(copy11);
                          setCount(3);
                        })   
                      }


                      if(count===3){
                        alert("더이상 상품이 없습니다.");  
                      }


                      }}> <span style={{fontFamily: 'Maven Pro'}}>+</span> View 
                      <span style={{fontFamily: 'Maven Pro'}}> 3 </span>more products</Button>{' '} 

                      <div className="container" style={{marginTop:'30px'}}>
                      <div className="row">
                          {
                          nike10.map((ele, i) => {
                          return (
                          <Nike nike10={nike10[i]}  />

                          )
                          })
                          }
                      </div>
                      </div>   
                       

                     



                {/* 여기까지 두번째 버튼 음식들  */}

                   

                  {/* ----여기까지 다이어트 샐러드 볼---  */}
                    
                  <Ship/>


                  <Under/>

                  <Footer/>


            </>
            </div>} />  {/* 이거 route path/닫은거 */}

          {/* ------여기까지 메인페이지 끝-------- */}





          {/* ------여기부터 상세페이지시작-------- */}
          <Route path="/detail/:id" element={<Detail shoes={shoes}/>} /> 
          <Route path="/cart" element={<Cart/>}/>
           {/* ------여기까지 상세페이지 끝-------- */}

        <Route path="/About" element={<About/>} >
          <Route path="member" element={<div>멤버임</div>} />
          <Route path="location" element={<div>위치</div>} />

        </Route>
</Routes>



 


     
    </div>  // 이게 마지막 app /div 임
  
  );
}


const Sliderline =()=>{
 
  return(
    <>
   
    <Container style={{marginTop:'80px'}}>

      <Row>

     
        <Col xs className='icons' > <img
                src="img/foodimg/eco.svg"
                style={{ height:'auto',
                  weight:'auto',
                  cursor:'pointer'
                }}
                ></img>
                <h3 style={{
                    fontSize:'30px',
                    padding:'20px 0 0 0px',
                    fontFamily: 'Crimson Text',
                    cursor:'pointer'
                }}>Eco</h3></Col>

   

        <Col xs={{ order: 12 }} className='icons'><img
                src="img/foodimg/islogical.svg"
                style={{ height:'auto',
                  weight:'auto',
                  cursor:'pointer'}}
                ></img>
                <h3 style={{
                    fontSize:'30px',
                    padding:'20px 0 0 0px',
                    fontFamily: 'Crimson Text',
                    cursor:'pointer'
                }}>Is Logical</h3></Col>

        <Col xs={{ order: 1 }} className='icons'> <img
                src="img/foodimg/yummy.svg"
                style={{ height:'auto',
                  weight:'auto',
                  cursor:'pointer'}}
                ></img>
                <h3 style={{
                    fontSize:'30px',
                    padding:'20px 0 0 0px',
                    fontFamily: 'Crimson Text',
                    cursor:'pointer'
                }}>Yummy</h3></Col>

        <Col xs={{ order: 1 }} className='icons'> <img
                src="img/foodimg/cheap.svg"
                style={{ height:'auto',
                  weight:'auto',
                  cursor:'pointer'}}
                ></img>
                <h3 style={{
                    fontSize:'30px',
                    padding:'20px 0 0 0px',
                    fontFamily: 'Crimson Text',
                    cursor:'pointer'
                }}>Cheaply</h3></Col>

      </Row>

    </Container>
    
    
          </>
    
  );
}



const Thirdline =()=>{
  let csst5 = {
    fontSize:"35px",
    display:'flex',
    justifyContent:'center',
    fontFamily: 'Abril Fatface', 
    padding:'80px 0 0 0px'
  }
  let csst6 = {
    fontSize:"25px",
    display:'flex',
    justifyContent:'center',
    fontFamily: 'Crimson Text', 
    padding:'5px 0 50px 0px',
    color:'#888888'
  }
  return(
    <>
      <h3 style={csst5}>We are Glad to Surprise You</h3>
      <p style={csst6}> Do not wait for tomorrow - start a new life today!</p>
    </>
  );
}

// ---MOST POPULAR 첫 라인-----

const Title =()=>{
  let csst1 = {
    marginTop:"70px",
    textAlign:'center',
    fontFamily: 'Abril Fatface', 
    fontSize:'40px'
  }

  let hrst={
    width:'80%',
    color:'green',
    margin:'30px auto'
  }
  return(
    <>
    <hr style={hrst}></hr>
      <h3 style={csst1}>Most Popular  </h3>
      <p style={{textAlign:'center',fontFamily: 'Crimson Text', color:'#888888', fontSize:"25px"}}> Enjoy the most delicious dishes!</p>
    </>
  );
}


// ---밑에 첫 상품들----



function Product(props) {
  let navigate = useNavigate();

  let contentst = {
    fontSize:"15px",
    margin:'15px',
    fontFamily: 'Abril Fatface',
    fontFamily: 'Maven Pro',
    color:"#777777"
  }

  let foodti2 = {
    fontSize:"15px",
    color:'orange',
    marginTop:'-20px'
    
  }

  let foodti = {
    fontSize:"23px",
    fontFamily: 'Cormorant Garamond',
    fontWeight:'600',
    marginTop:'10px'
  }

  let pricest = {
    fontSize:"20px",
    fontFamily: 'Maven Pro',
    fontWeight:600
  }

  let btnst = {
    fontSize:"18px",
    fontFamily: 'Cormorant Garamond',
    fontWeight:600,
    backgroundColor:'#64a862',
    color:'white',
    border:'none',
    padding:'10px',
    margin:'0 0 50px 0px',
    borderRadius:'10px',
    width:'130px'
  }

  
  return (
    <div className="col-md-3">
       <Nav.Link onClick={() => {navigate('/detail/'+ props.res1[props.i]) }} className="c1" >
          <img src={props.shoes.imgUrl} width="100%" />
          <p style={contentst}>{props.shoes.content}</p>
          <h4 style={foodti2}>{props.shoes.title2}</h4>
          <h5 style={foodti}>{props.shoes.title}</h5>

          <p style={pricest}>${props.shoes.price}</p>
          <button style={btnst}>Add To Cart</button>
      </Nav.Link>
    </div>
  );

}

// ---HEALTHY DIET  두번째 라인-----

const Title2 =()=>{
  let csst1 = {
    marginTop:"70px",
    textAlign:'center',
    fontFamily: 'Abril Fatface', 
    fontSize:'40px'
  }

  let hrst={
    width:'80%',
    color:'green',
    margin:'70px auto'
  }
  return(
    <>
    <hr style={hrst}></hr>
      <h3 style={csst1}>Healthy Diet Supplement </h3>
      <p style={{textAlign:'center',fontFamily: 'Crimson Text', color:'#888888', 
      fontSize:"25px"}}> 
      Enjoy your diet while eating delicious food!</p>
    </>
  );
}

// ---HEALTHY DIET 두번째 라인-----


function Nike(props) {

  let contentst = {
    fontSize:"15px",
    margin:'15px',
    fontFamily: 'Abril Fatface',
    fontFamily: 'Maven Pro',
    color:"#777777"
  }

  let foodti = {
    fontSize:"23px",
    fontFamily: 'Cormorant Garamond',
    fontWeight:'600',
    marginTop:'10px'
  }

  let pricest = {
    fontSize:"20px",
    fontFamily: 'Maven Pro',
    fontWeight:600
  }


  return (
    <div className="col-md-4">
        <img src={props.nike10.imgUrl} width="80%" />
        <p style={contentst}>{props.nike10.content}</p>
        <h5 style={foodti}>{props.nike10.title}</h5>
        <p style={pricest}>${props.nike10.price}</p>
      
    </div>
  );
}


const Ship =()=>{

  
  let containerst = {

    marginTop:'80px'
  }



  let shipst = {

    fontFamily: 'Abril Fatface',
    fontSize:'80px',
    display:'flex',
    color:'#64a862'
  }

  let shipst2 = {


    fontSize:'40px',
    display:'flex',
    flexWrap:'wrap',
    marginLeft:'20px',
    color:'black'
  }

  
  
  return(
    <>
    <div>
    
        <Container style={containerst} className='containerst'>
          <Row>

            <Col style={shipst}><div> <i class="fa-solid fa-truck-fast"></i> </div>

            <div style={shipst2}>Free shipping 
            <p style={{fontSize:'20px',color:'#777777',fontFamily: 'Maven Pro'}}>
              Free shipping on all US order or order above $49</p></div></Col>

              <Col style={shipst}><div>  <i class="fa-solid fa-wallet"></i> </div>

<div style={shipst2}>Payment
<p style={{fontSize:'20px',color:'#777777',fontFamily: 'Maven Pro'}}>
Credit Card: Visa, MasterCard, Maestro, American Express.</p></div></Col>


           
          </Row>
        </Container>
    
    
    </div>
    </>
  );
}




const Under =()=>{
  
  return(
    <>
      <div className='underimg'>
      <img src='img/foodimg/footerimg.png'/>
      </div>
    </>
  );
}



function Footer() {
  return (
      <div className='footer-container'>
          
          <div class='footer-links'>
              <div className='footer-link-wrapper'>
                  <div class='footer-link-items'>
                      <h2>About Us</h2>
                      <Link to='/sign-up'>How it works</Link>
                      <Link to='/'>Testimonials</Link>
                      <Link to='/'>Careers</Link>
                      <Link to='/'>Investors</Link>
                      <Link to='/'>Terms of Service</Link>
                  </div>
                  <div class='footer-link-items'>
                      <h2>Contact Us</h2>
                      <Link to='/'>Contact</Link>
                      <Link to='/'>Support</Link>
                      <Link to='/'>Destinations</Link>
                      <Link to='/'>Sponsorships</Link>
                  </div>
                 

                          <section className="footer-subscription">
                      <p className="footer-subscription-heading">
                      NEWSLETTER SIGNUP
                      </p>
                      
                      <p className="footer-subscription-text">
                      Sign up for our e-mail and be the first who know our special offers!
                      </p>
                      <div className="input-areas">
                          <form>
                              <input type="email" name = "email" placeholder = "Your Email" 
                              className="footer-input"/>
                              <Button  
                              style={{backgroundColor:'#64a862' ,
                              border:'4px solid #64a862',marginBottom:'18px'}}>
                                join us</Button>
                          </form>
                      </div>
                  </section>
                      </div>
                  </div>
                  <section className="social-media">
                      <div className="social-media-wrap">
                          <div className="footer-logo">
                              <Link to='/' className="social-logo">
                                  Ecofood <i className="fab fa-typo3"></i>
                              </Link>
                          </div>
                          <small className="website-rights">© Wokiee 2022. Made with  by HasThemes.</small>
                          <div className="social-icons">
                              <Link className="social-icon-link facebook" to="/"
                              target = "_blank"
                              aria-label="Facebook"
                              >
                                  <i className="fab fa-facebook-f"></i>
                              </Link>
                              <Link className="social-icon-link instagram" to="/"
                              target = "_blank"
                              aria-label="Instagram"
                              >
                                  <i className="fab fa-instagram"></i>
                              </Link>
                              <Link class='social-icon-link youtube'
                              to='/'
                              target='_blank'
                              aria-label='Youtube'
                              >
                              <i class='fab fa-youtube' />
                              </Link>
                              <Link
                              class='social-icon-link twitter'
                              to='/'
                              target='_blank'
                              aria-label='Twitter'
                              >
                              <i class='fab fa-twitter' />
                              </Link>
                              <Link
                              class='social-icon-link twitter'
                              to='/'
                              target='_blank'
                              aria-label='LinkedIn'
                              >
                              <i class='fab fa-linkedin' />
                              </Link>
                          </div>
                      </div>
                  </section>
                

      </div>
  )
}

// ---네비게이션 ABOUT이랑 MEMBER----

function About(){
  return(
   <>
     <h4>회사정보임</h4>
     <Outlet></Outlet>
   </>
  );
}





export default App;
