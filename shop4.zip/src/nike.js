let nike = [
    {
        'id': 1,
        'title': "Cold Cut Granola Salady",
        'imgUrl': "img/nike/salad1.jpg",
        'content': "Recommended for dieters",
        'price': 259000
    },
    {
        'id': 2,
        'title': "Caesar Chicken Salady",
        'imgUrl': "img/nike/salad2.jpg",
        'content': "Satisfied with a simple meal!",
        'price': 239000
    },
    {
        'id': 3,
        'title': "Tandaji Salady",
        'imgUrl': "img/nike/salad3.jpg",
        'content': "Take protein according to your balance",
        'price': 219000
    }
      
  ]
  
  export default nike;